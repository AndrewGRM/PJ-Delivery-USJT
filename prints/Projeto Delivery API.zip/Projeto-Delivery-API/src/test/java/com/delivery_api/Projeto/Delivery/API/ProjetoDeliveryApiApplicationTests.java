package com.delivery_api.Projeto.Delivery.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoDeliveryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
